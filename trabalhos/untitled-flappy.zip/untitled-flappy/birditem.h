#ifndef BIRDITEM_H
#define BIRDITEM_H

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QPropertyAnimation>
#include <QDebug>

class BirdItem : public QObject, public QGraphicsPixmapItem
{
    //Q_OBJECT

    Q_PROPERTY(qreal rotation READ rotation WRITE setRotation) // getters e setters
    Q_PROPERTY(qreal y READ y WRITE setY)

public:
    explicit BirdItem(QPixmap pixmap);
//---
    qreal rotation() const;

    qreal y() const; //y
//---

signals:

public slots:
    //---
    void setRotation(qreal rotation); // diferente -> qreal rotation
    void setY(qreal y); // diferente (newY) mas mudei p  qreal y

    void rotateTo(const qreal &end, const int& duration, const QEasingCurve& curve);

private:
    enum WingPosition{
        Up,
        Middle, // como não teriamos essa opção vou colocar a mesma imagem
        Down
    };
    void updatePixmap();

    WingPosition wingPosition;
    bool wingDirection; // 0 = para baixo 1 = para cima

    qreal m_rotation;
    qreal m_y;

    //--
    QPropertyAnimation * yAnimation;
    QPropertyAnimation * rotationAnimation; //
    qreal groundPosition;
    // --
};

#endif // BIRDITEM_H
