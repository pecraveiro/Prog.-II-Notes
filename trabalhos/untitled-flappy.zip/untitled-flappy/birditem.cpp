#include "birditem.h"
#include <QTimer>

BirdItem::BirdItem(QPixmap pixmap) : wingPosition(WingPosition::Up), wingDirection(0)
{
    setPixmap(pixmap); // local onde o pássaro irá aparecer

    QTimer * birdWingsTimer = new QTimer(this);
    connect(birdWingsTimer,&QTimer::timeout,[=](){
        updatePixmap();
    });

    birdWingsTimer->start(80);

//-- queda do pássaro
    groundPosition = scenePos().y() + 290; //290

    yAnimation = new QPropertyAnimation(this,"y",this);
    yAnimation->setStartValue(scenePos().y());
    yAnimation->setEndValue(groundPosition);
    yAnimation->setEasingCurve(QEasingCurve::InQuad);
    yAnimation->setDuration(1000); //1 segundo

    yAnimation->start();
//--

//-- rotation

    rotationAnimation = new QPropertyAnimation(this, "rotation",this);
    rotateTo(90,1200,QEasingCurve::InQuad);
//--
}

// gerados pelo refactor 2.0 e já foi direto pro cpp
qreal BirdItem::rotation() const
{
    return m_rotation;
}

void BirdItem::setRotation(qreal rotation)
{
    m_rotation = rotation;

//-- novo dps de arrumar a queda do bird
    QPointF c = boundingRect().center();
    QTransform t;
    t.translate(c.x(), c.y());
    t.rotate(rotation); //diferente -> rotation
    t.translate(-c.x(),-c.y());
    setTransform(t);
//--
}

qreal BirdItem::y() const
{
    return m_y;
}

// não está funcionando
void BirdItem::setY(qreal y)
{
    qDebug() << "to caindo?: " << y;
    moveBy(0,y-m_y);
    m_y = y;
}

// - rotação do bird quando ele cai
void BirdItem::rotateTo(const qreal &end, const int &duration, const QEasingCurve &curve)
{
    rotationAnimation->setStartValue(rotation()); //newRotation
    rotationAnimation->setEndValue(end);
    rotationAnimation->setEasingCurve(curve);
    rotationAnimation->setDuration(duration);

    rotationAnimation->start();
}

// Movimentação das asas para dar uma animação
void BirdItem::updatePixmap()
{
    if (wingPosition == WingPosition::Middle){
        if (wingDirection){
            // Up
            setPixmap(QPixmap(":/images/resized-bird_yellow_up.png")); // imagem do pássaro com a asa para cima
            wingPosition = WingPosition::Up;
            wingDirection = 0;
        }else{
            //Down
            setPixmap(QPixmap(":/images/resized-bird_yellow_down.png"));
            wingPosition = WingPosition::Down;
            wingDirection = 1;
        }
    }else{
        setPixmap(QPixmap(":/images/resized-bird_yellow_up.png")); // trocar essa imagem depois
        wingPosition = WingPosition::Middle;
    }
}
