#ifndef SCENE_H
#define SCENE_H

#include <QGraphicsScene>
#include <QTimer> // para adicionar vários pilares em um período de tempo
#include "pillaritem.h"

class Scene : public QGraphicsScene
{
public:
    explicit Scene(QObject *parent = nullptr);

signals:

public slots:
private:
    void setUpPillarTimer();

    QTimer * pillarTimer;
};

#endif // SCENE_H
