#ifndef PILLARITEM_H
#define PILLARITEM_H

#include <QGraphicsItemGroup>
#include <QGraphicsPixmapItem>
#include <QPropertyAnimation>

class PillarItem : public QObject, public QGraphicsItemGroup
{
    Q_OBJECT
    Q_PROPERTY(qreal x READ x WRITE setX)
public:
    explicit PillarItem();
    ~PillarItem(); //refactor (leftclick)


    qreal x() const; // left click gerou isso
    void setX(qreal newX); // left click gerou isso

signals:
public slots:
    //void setX(qreal x);

private:
    QGraphicsPixmapItem * topPillar; // pilar de cima
    QGraphicsPixmapItem * bottomPillar; // pilar de baixo
    QPropertyAnimation * xAnimation;

    int yPos;

    qreal m_x; // left click gerou isso
};

#endif // PILLARITEM_H
