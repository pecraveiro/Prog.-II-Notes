#include "pillaritem.h"
#include <QRandomGenerator>
#include <QDebug>
#include <QGraphicsScene> // remove item function

PillarItem::PillarItem() : topPillar(new QGraphicsPixmapItem(QPixmap(":/images/pillarLP2.png"))), bottomPillar(new QGraphicsPixmapItem(QPixmap(":/images/pillarLP2.png")))

{
    // Centralizando os pilares
    topPillar->setPos(QPointF(0,0) - QPointF(topPillar->boundingRect().width()/2, topPillar->boundingRect().height() +60));

    bottomPillar->setPos(QPointF(0,0) + QPointF(-bottomPillar->boundingRect().width()/2, 60));

    // temos acesso a esse método por que é um método de QGraphicsPixmapItem
    // addToGroup método
    addToGroup(topPillar);
    addToGroup(bottomPillar);

    // randomiza a geração dos pilares
    yPos = QRandomGenerator::global()->bounded(150);
    int xRandomizer = QRandomGenerator::global()->bounded(200);

    setPos(QPoint(0,0) + QPoint(260 + xRandomizer, yPos));

    // gera a animação dos pilares
    xAnimation = new QPropertyAnimation(this, "x", this);
    xAnimation->setStartValue(260 + xRandomizer);
    xAnimation->setEndValue(-260);
    xAnimation->setEasingCurve(QEasingCurve::Linear);
    xAnimation->setDuration(1500); //1500milisegundos = 1,5 segundos

    connect(xAnimation, &QPropertyAnimation::finished,[=](){
        qDebug() << "Animation FINISHED";
        scene()->removeItem(this);
        delete this;
    });

    xAnimation->start();
}

PillarItem::~PillarItem()
{
    qDebug() << "Deleting pillar";
}

qreal PillarItem::x() const // left click gerou isso
{
    return m_x;
}

void PillarItem::setX(qreal x) // left click gerou isso
{
    //qDebug() << "Pillar position: " << x;
    m_x = x;
    setPos(QPointF(0,0) + QPointF(x,yPos));
}
