// File circle.cpp

#include "circle.h"

// PI is local to this file
static const double PI = 3.14159;

Circle::Circle(double radius): Ellipse(radius, radius) {}

// Uma variável estática é uma variável que foi alocada "estaticamente", o que significa que seu tempo de vida (ou "extensão") é toda a execução do programa.