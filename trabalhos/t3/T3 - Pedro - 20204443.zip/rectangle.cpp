// File rectangle.cpp

#include "rectangle.h"
#include <algorithm> // For max function

// Geralmente para retângulos comprimento >= largura, mas o construtor não impõe isso.
// Construtor
Rectangle::Rectangle(double len, double wid): length(len), width(wid) {}

// Determina o maior lado
double Rectangle::span() const //span = maior lado
{
return std::max(length, width); // A função max determina o maior valor entre os 2
}

double Rectangle::area() const // Cálcula a área do retângulo
{
return length * width;
}

/* 
   /--------------------------------/ 
   /                                /
   /                                /
   /      A = base x altura         /
   /                                /
   /                                /
   /--------------------------------/
*/