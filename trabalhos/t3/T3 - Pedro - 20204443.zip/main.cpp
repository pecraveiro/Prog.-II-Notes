/* 
 ---------------------------------------------------------------------------
|  Trabalho - T3 - Unidade 03 - Programação Orientada a Objetos             |
|  Aluno: Pedro Muhamad Suleiman Craveiro                                   |
|  Matrícula: 20204443                                                      |
|  Universidade UFSC - Campus Araranguá                                     |
|  Data: 04/06 - Entrega Final 05/07.                                       |
|  Console online: https://onlinegdb.com/zGuu30-zj                          |
|  Youtube: https://youtu.be/qG3Vz8zxzzc                                    |
|  Github: https://github.com/pecraveiro/Prog.-II-Notes/tree/main/trabalhos |
 ---------------------------------------------------------------------------
*/

// O programa é um desenvolvimento de um conteúdo semelhante ao que foi ministrado em sala de aula

#include <iostream>
#include <vector>
#include "rectangle.h"
#include "triangle.h"
#include "circle.h"
#include "ellipse.h"

int main() {
    Rectangle rect(3, 4);
    Circle circ(4.5);
    Triangle tri(3, 4, 5);
    Ellipse elli(3, 4);

    std::vector<Shape *> shape_list; // Vetor para a lista de formas
    shape_list.push_back(&circ); // Área do circulo
    shape_list.push_back(&tri); // Área do triângulo
    shape_list.push_back(&rect); // Área do retângulo
    shape_list.push_back(&elli); // Área da elipse

    int n = shape_list.size();
    double area_total = 0.0, max_span = 0.0;

    for (int i = 0; i < n; i++) {
    // Examine the area each shape
    std::cout << "Area = " << shape_list[i]->area() << std::endl;
    
    // Accumulate the areas of all the shapes - Soma a área de todas as formas
    area_total += shape_list[i]->area();
    
    // Account for the longest object - Maior lado entre os todas as formas
    if (max_span < shape_list[i]->span())
    max_span = shape_list[i]->span();
    }
    
    // Report the total area of all the shapes combined
    std::cout << "Total shape area is: " << area_total << std::endl;
    // Report the maximum length of the container
    std::cout << "Longest shape is: " << max_span << std::endl;
}