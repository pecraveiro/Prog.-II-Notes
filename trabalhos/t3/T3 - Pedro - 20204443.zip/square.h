#ifndef SQUARE_H_
#define SQUARE_H_

#include "rectangle.h"
// O quadrado é um caso especial do retângulo, onde se multiplicarmos o comprimento pela largura, seria a mesma coisa que Lado * Lado, portanto tempos a área do quadrado dessa forma também. 
class Square: public Rectangle {
public:
// Length and width are equal in a square, so specify the length of only one side
Square(double side);
// The inherited methods work as is; no need to change their behavior.
};

#endif