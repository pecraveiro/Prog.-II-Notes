#ifndef TRIANGLE_H_
#define TRIANGLE_H_
#include "shape.h"

class Triangle: public Shape {
protected:
    // Triangles have three sides
    double side1; // lado1
    double side2; // lado2
    double side3; // lado3
public:
    Triangle(double s1, double s2, double s3);
    double span() const override; // método de sobreposição e maior lado do triangulo
    double area() const override; // " e cálcula a área do triângulo
};

#endif