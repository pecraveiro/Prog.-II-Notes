/* -----------------------------------------------
  Prova de Recuperação - C++
  Aluno: Pedro Muhamad Suleiman Craveiro
  Matrícula: 20204443
  Universidade UFSC - Campus Araranguá
  COMPILADOR ONLINE: https://onlinegdb.com/A5xc47xPs
   -----------------------------------------------
*/

/*
class Empregado { // Superclasse - classe mãe
    private:
        string nome;
        string sobrenome;
        string cpf;
    public:
        double vencimento();
};

class Assalariado : Empregado { // a classe Assalariado herda atributos e métodos da classe mãe Empregado
    private:
        double salario;
    public:
        double vencimento();
};

class Comissionado : Empregado { // a classe Comissionado herda atributos e métodos da classe mãe Empregado
    private:
        double totalVenda;
        double taxaComissao;
    public:
        double vencimento();
};

class Horista : Empregado { // a classe Horista herda atributos e métodos da classe mãe Empregado
    private:
        double precoHora;
        double horasTrabalhadas;
    public:
        double vencimento();
    
};
*/

#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

void PrintList(const vector<pair<string, vector<string>>> &List); 
bool RemoveString(string str, vector<pair<string, vector<string>>> &List);
bool LoadFile(string filename, vector<pair<string, vector<string>>> &List);
bool SaveFile(string filename, const vector<pair<string, vector<string>>> &List);
bool Search(string str, const vector<string> &List, size_t &pos);
bool SearchSubstr(string str, const vector<pair<string, vector<string>>> &List, vector<size_t> &indices); // search empregado
void PrintListStatistic(const vector<pair<string, vector<string>>> &List);
void RemoveWord(string SubStr, vector<pair<string, vector<string>>> &data); //remove empregado

int main() {
  vector<pair<string, vector<string>>> ListOfer;
  vector<string> ListOfWords;
  
  char ch;

  for (;;) 
  {
    // Menu elaborado
    cout << endl;
    cout << "------------------===--------------------" << endl;
    cout << "|            Rec UFXC LP2               |" << endl;
    cout << "| 1 - Abrir a ficha de um empregado...  |" << endl;
    cout << "| 2 - Procurar o empregado...           |" << endl; // procurar o nome do funcionario
    cout << "| 3 - Remover infomacoes do empregado...|" << endl; // remover dados do funcionario
    cout << "|                                       |" << endl;
    cout << "| 5 - Sair do programa                  |" << endl;  
    cout << "------------------===--------------------" << endl;
    cout << "Digite uma opcao: ";

    cin >> ch;

    if (ch == '1') {
      cout << "Coloque o nome do seu arquivo abaixo (no formatos adequados '.txt') e o programa retorna-ra os relatorios: ";
      string str;
      cin >> str;
      LoadFile(str, ListOfer);
      PrintList(ListOfer);
      continue;
    } 
    if (ch == '2') {
      cout << endl << "Digite o nome do empregado conforme sua ficha: "; // Com os arquivos "abertos" digite o nome do empregado para remove-lo
      string str;
      cin >> str;
      vector<size_t> indices;
      if (SearchSubstr(str, ListOfer, indices) == true) {
        cout << "Numero de substrings encontradas: " << indices.size() << endl; 
        for (size_t i = 0; i < indices.size(); i++) {
          cout << ListOfer.at(indices.at(i)).first << " contem o empregado " << ListOfer.at(i).second.at(indices.at(i)) << endl;
        }
      } else {
        cout << "Empregado não encontrado." << endl; // empregado nao encontrado
      }
      continue;
    }
    if (ch == '3') {
      cout << "Digite uma palavra referente a sua ficha para remover infomaçoes do empregado:" << endl; //
      string str;
      cin >> str;
      RemoveWord(str, ListOfer); //removeword = removeempregado
      continue;
    }

    //if (ch == '4') {
     //cout << "Enter with a word to remove: ";
      //string str;
      //cin >> str;
      //if (!RemoveString(str, ListOfer))
        //cout << endl << "Nothing to remove" << endl;
      //continue;
    //}

    //if (ch == '5') {
      //PrintListStatistic(ListOfer);
      //continue;
    //}
    
    if (ch == '5') {
      SaveFile("relatorio.txt", ListOfer);
      cout << "Seu relatorio está atualizado e criado."; // Seu relatorio está atualizado e criado.
      break;
    }
    else {
      cout << "Coloque um numero valido no menu.";
    }
  }

  return 0;
}

void PrintList(const vector<pair<string, vector<string>>> &List) {
  for (size_t i = 0; i < List.size(); i++) {
    for (size_t j = 0; j < List.at(i).second.size(); j++) {
      cout << List.at(i).second.at(j) << endl;
    }
  }
}

void PrintListStatistic(const vector<pair<string, vector<string>>> &List) {
  for (size_t i = 0; i < List.size(); i++) {
    for (size_t j = 0; j < List.at(i).second.size(); j++) {
      cout << List.at(i).first << " has " << List.at(i).second.at(j).length() << " words." << endl;
    }
  }
}

bool RemoveString(string str, vector<pair<string, vector<string>>> &List) {
  bool hasErase = false;
  for (unsigned int i = 0; i < List.size(); i++) {
    for (int j = 0; j < List.at(i).second.size(); j++) {
      vector<string> fileData = List.at(i).second;
      size_t pos = fileData.at(i).find(str);
      if (pos != string::npos)
      {
        List.at(i).second.erase(List.at(i).second.begin() + i);
        hasErase = true;
        cout << "remove string." << endl;
      }
    }
  }
  return hasErase;
}

bool SaveFile(string filename, const vector<pair<string, vector<string>>> &List) {
  ofstream fileWriter(filename);
  if (!fileWriter.is_open()) {
    cout << "Error, cannot open file." << endl;
    return false;
  }
  for (size_t i = 0; i < List.size(); i++) {
    for (size_t j = 0; j < List.at(i).second.size(); j++) {
      fileWriter << List.at(i).second.at(j) << endl;
    }
  }
  fileWriter.close();
  return true;
}

bool LoadFile(string filename, vector<pair<string, vector<string>>> &List) {
  ifstream fileReader(filename);
  if (fileReader.is_open()) {
    string tmp;
    vector<string> content;
    while (getline(fileReader, tmp)) {
      content.push_back(tmp);
    }
    List.push_back(make_pair(filename, content));
  } else {
    cout << "Error, cannot open the file." << endl;
    return false;
  }

  fileReader.close();
  return true;
}

bool Search(string str, const vector<string> &List, size_t &pos) {
  for (size_t i = 0; i < List.size(); i++) {
    if (List.at(i) == str) {
      pos = i;
      return true;
    }
  }
  return false;
}

bool SearchSubstr(string str, const vector<pair<string, vector<string>>> &List, vector<size_t> &indices) {
  for (size_t i = 0; i < List.size(); i++) {
    for (size_t j = 0; j < List.at(i).second.size(); j++) {
      string word = List.at(i).second.at(j);
      size_t pos = word.find(str);
      if (pos < word.length()) {
        indices.push_back(j);
      }
    }
  }
  return true;
}

bool RemoveStringIgual(string str, vector<pair<string, string>> &Files, vector<int> &indices) {
  bool hasErase = false;
  for (unsigned int i = 0; i < Files.size(); i++) {
    string fileData = Files.at(i).second;
    size_t pos = fileData.find(str);
    if (pos != string::npos) // nao achou
    {
      Files.at(i).second.erase(Files.at(i).second.begin() + i);
      hasErase = true;
      cout << "remove string" << endl;
    }
  }
  return hasErase;
}

void RemoveWord(string SubStr, vector<pair<string, vector<string>>> &data) {
  for (int i = 0; i < data.size(); i++) {
    for (int j = 0; j < data.at(i).second.size(); j++) {
      size_t found;
      found = data.at(i).second.at(j).find(SubStr, 0);

      if (found != string::npos) {
        data.at(i).second.erase(data.at(i).second.begin() + j);
      }
    }
  }
}